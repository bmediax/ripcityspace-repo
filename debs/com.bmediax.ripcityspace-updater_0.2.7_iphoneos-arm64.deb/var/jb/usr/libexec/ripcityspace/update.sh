#!/var/jb/bin/sh
# Pulls updates for the Rip City Space packages from the package repo. Run by launchd on a timer.
# Wrapped in a function with `main; exit` on one line so the script can safely replace itself mid-run.
main() {
	export PATH=/var/jb/usr/bin:/var/jb/bin:/var/jb/usr/sbin:/var/jb/sbin:$PATH
	export DEBIAN_FRONTEND=noninteractive
	LIST=/var/jb/etc/ripcityspace/apt.list
	APT_OPTS="-o Dir::Etc::sourcelist=$LIST -o Dir::Etc::sourceparts=/dev/null -o APT::Get::List-Cleanup=0"

	echo "=== $(date)"
	apt-get $APT_OPTS update || return 1
	apt-get $APT_OPTS install -y --only-upgrade -o Dpkg::Options::=--force-confold \
		com.bmediax.ripcityspace com.bmediax.ripcityspace-launcher \
		com.bmediax.ripcityspace-debug com.bmediax.ripcityspace-updater
}
main >> /var/tmp/ripcityspace-update.log 2>&1; exit $?
