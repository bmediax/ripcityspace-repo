#!/var/jb/bin/sh
# Keeps the Rip City Space packages up to date. Runs as a launchd KeepAlive daemon: check, wait, repeat.
# (launchd's StartInterval fires unreliably on iOS, so the loop lives here.)
INTERVAL=600
SELF=/var/jb/usr/libexec/ripcityspace/update.sh
export PATH=/var/jb/usr/bin:/var/jb/bin:/var/jb/usr/sbin:/var/jb/sbin:$PATH
# Creating this file (any user can, for example over SSH) makes the next check happen right away.
TRIGGER=/var/tmp/ripcityspace-update-now

main() {
	export PATH=/var/jb/usr/bin:/var/jb/bin:/var/jb/usr/sbin:/var/jb/sbin:$PATH
	export DEBIAN_FRONTEND=noninteractive
	LIST=/var/jb/etc/ripcityspace/apt.list
	APT_OPTS="-o Dir::Etc::sourcelist=$LIST -o Dir::Etc::sourceparts=/dev/null -o APT::Get::List-Cleanup=0 -o Acquire::Languages=none"

	echo "=== $(date)"
	apt-get $APT_OPTS update || return 1
	apt-get $APT_OPTS install -y --only-upgrade -o Dpkg::Options::=--force-confold \
		com.bmediax.ripcityspace com.bmediax.ripcityspace-launcher \
		com.bmediax.ripcityspace-debug com.bmediax.ripcityspace-notifier com.bmediax.ripcityspace-updater
}

wait_for_next() {
	waited=0
	while [ "$waited" -lt "$INTERVAL" ]; do
		[ -e "$TRIGGER" ] && break
		sleep 5
		waited=$((waited + 5))
	done
	rm -f "$TRIGGER"
}

# Upgrading this package replaces the script on disk; notice that and restart onto the new code.
loop() {
	stamp=$(cksum < "$SELF")
	while :; do
		main >> /var/tmp/ripcityspace-update.log 2>&1
		wait_for_next
		[ "$(cksum < "$SELF")" != "$stamp" ] && exec "$SELF"
	done
}

# Run once and exit when given "once" (for manual use); otherwise loop forever.
if [ "$1" = "once" ]; then
	main >> /var/tmp/ripcityspace-update.log 2>&1
	tail -n 25 /var/tmp/ripcityspace-update.log
	exit $?
fi
loop
