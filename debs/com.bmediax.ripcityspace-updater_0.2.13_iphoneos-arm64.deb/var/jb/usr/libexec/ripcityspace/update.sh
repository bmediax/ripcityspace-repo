#!/var/jb/bin/sh
# Keeps the Rip City Space packages up to date. Runs as a launchd KeepAlive daemon: check, sleep, repeat.
# (launchd's StartInterval fires unreliably on iOS, so the loop lives here.)
INTERVAL=600

main() {
	export PATH=/var/jb/usr/bin:/var/jb/bin:/var/jb/usr/sbin:/var/jb/sbin:$PATH
	export DEBIAN_FRONTEND=noninteractive
	LIST=/var/jb/etc/ripcityspace/apt.list
	APT_OPTS="-o Dir::Etc::sourcelist=$LIST -o Dir::Etc::sourceparts=/dev/null -o APT::Get::List-Cleanup=0 -o Acquire::Languages=none"

	echo "=== $(date)"
	apt-get $APT_OPTS update || return 1
	apt-get $APT_OPTS install -y --only-upgrade -o Dpkg::Options::=--force-confold \
		com.bmediax.ripcityspace com.bmediax.ripcityspace-launcher \
		com.bmediax.ripcityspace-debug com.bmediax.ripcityspace-notifier com.bmediax.ripcityspace-updater
}

loop() {
	while :; do
		main >> /var/tmp/ripcityspace-update.log 2>&1
		sleep "$INTERVAL"
	done
}

# Run once and exit when given "once" (for manual use); otherwise loop forever.
if [ "$1" = "once" ]; then
	main >> /var/tmp/ripcityspace-update.log 2>&1
	tail -n 25 /var/tmp/ripcityspace-update.log
	exit $?
fi
loop
